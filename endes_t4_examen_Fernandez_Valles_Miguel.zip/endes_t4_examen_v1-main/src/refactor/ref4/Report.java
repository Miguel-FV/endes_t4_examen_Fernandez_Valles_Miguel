package refactor.ref4;


class Report {

    private static void extracted() {
        System.out.println("Título del Reporte");
    }
    private static void content() {

        System.out.println("Contenido 1...");
        System.out.println("Contenido 2...");

    }
    private static void conclusion(){

        System.out.println("Conclusión del Reporte");
    }
}
