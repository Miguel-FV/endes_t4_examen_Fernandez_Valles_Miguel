package refactor.ref1;
/*
Tarea: Refactorizar el método processOrder para utilizar un objeto
de parámetro que contenga itemName, quantity, price, y customerName.
 */


class Order {

        public class processOrder {
            private String itemName;
            private int quantity;
            private double price;
            private String customerName;

    }
}
