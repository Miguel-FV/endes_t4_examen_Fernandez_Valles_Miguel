package refactor.ref3;

/*
Tarea: Renombrar "s" e "y" a nombres más descriptivos.
 */

public class Employee {
    int salary;
    int year;

    int calculateSalary() {
        return salary * year;
    }
}
