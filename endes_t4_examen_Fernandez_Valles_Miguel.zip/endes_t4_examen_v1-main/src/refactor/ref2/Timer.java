package refactor.ref2;

/*
Tarea: Reemplazar el número mágico 86400 con una constante descriptiva.
 */
public class Timer {
    static final int dia = 86400;
    void startTimer() throws InterruptedException {

        // Espera 86400 segundos (24 horas)
        try {
            Thread.sleep(dia);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

}