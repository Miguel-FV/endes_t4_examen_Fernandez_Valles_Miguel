package javadoc;

/**
 * La clase Empleado representa un  con propiedades basicas y metodo
 * para acceder y modificar esas propiedades
 *
 * @author Miguel
 * @version 1.0
 * @since 2024-02-23
 */


/**
 * Los atributos de la clase empleado
 */
public class Empleado {
    private String nombre;
    private String id;
    private double sueldo;


    /**
     * Constructor para crear diversos objetos
     *
     * @param nombre
     * @param id
     * @param sueldo
     */
    public Empleado(String nombre, String id, double sueldo) {
        this.nombre = nombre;
        this.id = id;
        this.sueldo = sueldo;
    }

    /**
     * Obtiene un nombre
     * @return nombre
     */

    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del empleado
     *
     * @param nombre el nuevo nombre del empleado
     */

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene un id
     * @return id
     */

    public String getId() {
        return id;
    }

    /**
     * Obtiene el sueldo
     * @return sueldo
     */

    public double getSueldo() {
        return sueldo;
    }

    /**
     * Establece el sueldo del empleado
     *
     * @param sueldo el nuevo nombre del empleado
     */

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    /**
     * Establece el incremento de sueldo del empleado
     *
     * @param incremento el nuevo nombre del empleado
     */

    public void incrementarSueldo(double incremento) {
        this.sueldo += incremento;
    }
    /**
     * metodo con override que devuelve un nombre, id y sueldo
     * @return nombre
     * @return id
     * @return sueldo
     */

    @Override
    public String toString() {
        return "javadoc.Empleado{" +
                "nombre='" + nombre + '\'' +
                ", id='" + id + '\'' +
                ", sueldo=" + sueldo +
                '}';
    }
}
