package javadoc;

import java.util.ArrayList;
import java.util.List;

/**
 * La clase Empleado representa un  con propiedades basicas y metodo
 * para acceder y modificar esas propiedades
 *
 * @author Miguel
 * @version 1.0
 * @since 2024-02-23
 */

/**
 * clase GestorPersonal
 */
public class GestorPersonal {

    /**
     * Nueva Lista de empleados sin empleados inicialmente
     */

    private List<Empleado> empleados;

    /**
     * se inicializa la lista
     */
    public GestorPersonal() {
        empleados = new ArrayList<>();
    }

    /**
     * Agrega un nuevo empleado al gestor personal
     *
     * @param empleado El empleado se añade al gestor personal al ser contratado
     */
    public void contratar(Empleado empleado) {
        empleados.add(empleado);
    }

    /**
     * Quitar al despedir a un empleado del gestor personal
     * @param id
     * @return empleado el empleado se quita de la lista al ser despedido
     */
    public boolean despedir(String id) {
        return empleados.removeIf(e -> e.getId().equals(id));
    }

    /**
     * Cambiar el suelo del empleado usando su id para saber quien es
     * @param id identificador del empleado al que le subiremos el sueldo
     * @param nuevoSueldo nuevo sueldo
     * @return en caso de no tener ID nueva no se cambiara el sueldo
     */
    public boolean cambiarSueldo(String id, double nuevoSueldo) {
        for (Empleado empleado : empleados) {
            if (empleado.getId().equals(id)) {
                empleado.setSueldo(nuevoSueldo);
                return true;
            }
        }
        return false;
    }

    /**
     * nos devuelve las personas que estan empleadas actualmente
     * @return la lista de empleados
     */

    public List<Empleado> getEmpleados() {
        return new ArrayList<>(empleados);
    }
}
